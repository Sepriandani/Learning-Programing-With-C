//Praktikum Pemecahan Masalah dengan C
//Tugas Praktikum : 1
//Problem         : 1
//Tanggal         : 24 Maret 2019
//Nama (NIM)      : Seprian Dani (13117023)
//Nama File       : Probem_1.c
//Deskripsi       : ASCII code
#include<stdio.h>

int main()
{
    printf("Hello World!\n"); //tulisan yang akan ditampilkan

    return 0;
}
