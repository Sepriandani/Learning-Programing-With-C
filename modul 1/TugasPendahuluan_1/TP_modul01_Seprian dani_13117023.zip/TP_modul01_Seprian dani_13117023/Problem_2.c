//Praktikum Pemecahan Masalah dengan C
//Tugas Praktikum : 1
//Problem         : 2
//Tanggal         : 24 Maret 2019
//Nama (NIM)      : Seprian Dani (13117023)
//Nama File       : Probem_2.c
//Deskripsi       : ASCII code
#include<stdio.h>

int main()
{
    //deklarasi variabel
    char nama[32];

    //algoritma
    printf("Masukkan Nama anda :");
    scanf("%s",&nama);
    printf("Hello World, %s!\n",nama);

    return 0;
}
