//praktikum EL2208 Pemecahan Masalah Dengan C
//Tugas Praktikum   :1
//Problem           :1
//Tanggal           :25 maret 2019
//Nama(nim)         :Alhadi Ihsan (13117090)
//Nama File         :Tugas Praktikum problem1.c
//Deskripsi         :ASCII code
#include <stdio.h>
int main (void)
{
    printf ("hello world!\n");
    return 0;
}
