//praktikum EL2208 Pemecahan Masalah Dengan C
//Tugas Praktikum   :1
//Problem           :1
//Tanggal           :25 maret 2019
//Nama(nim)         :Alhadi Ihsan (13117090)
//Nama File         :Tugas Praktikum problem2.c
//Deskripsi         :ASCII code
#include <stdio.h>
int main (void)
{
    char nama_orang[32];
    printf ("Masukan Nama Anda\n");
    scanf ("%s",&nama_orang);
    printf ("Hello World  %s!\n",nama_orang);
    return 0;
}

