//Praktikum EL2208 Pemecah Masalah dengan C
//Modul		: 2
//Percobaan	: 2
//Tanggal	: 22 Februari 2018
//Nama(NIM)	: Indah Dwi Rizki Amas (13116010)
//Nama file	: Problem1
//Deskripsi	: sebuah program untuk menampilkan hasil bilangan gantil atau genap sesuai dengan inputan.

#include <stdio.h>

int main (void)
{
	//Deklarasi Varabel
	int a,b;
	
	//Algoritma
	printf	("Masukkan Bilangan yang ingin ditentukan	: ");
	scanf	("%d", &a);
	printf	("Masukkan Bilangan yang ingin ditentukan	: ");
	scanf	("%d", &b);
	
	if (a%2==0){
		printf ("%d adalah Bilangan GENAP\n", a);
	}else {
		printf ("%d adalah Bilangan GANJIL\n", a);
	}
	if (b%2==0){
		printf ("%d adalah Bilangan GENAP\n", b);
	}else {
		printf ("%d adalah Bilangan GANJIL\n", b);
	}
	return 0;
}

