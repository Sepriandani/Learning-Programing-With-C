//Praktikum EL2208 Pemecah Masalah dengan C
//Modul		: 2
//Percobaan	: 2
//Tanggal	: 22 Februari 2018
//Nama(NIM)	: Indah Dwi Rizki Amas (13116010)
//Nama file	: Problem2
//Deskripsi	: sebuah program untuk menghitung luas segitiga

#include <stdio.h>
#include <math.h>

int main (void){
	//Deklarasi Variabel
	int a, b, c;
	float s;
	double luas;
	
	//Algoritma
	printf	("Masukkan besar sisi pertama	: ");
	scanf	("%d", &a);
	printf	("Masukkan besar sisi kedua	: ");
	scanf	("%d", &b);
	printf	("Masukkan besar sisi ketiga	: ");
	scanf	("%d", &c);
	
	//Perhitungan
	s = (a+b+c)/2;
	luas = sqrt(s*(s-a)*(s-b)*(s-c));
	
	//Output
	printf	("\nBesar Luas Segitiga		: %.2f\n", luas);
	return 0;
	
}
