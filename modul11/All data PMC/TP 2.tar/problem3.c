//Praktikum EL2208 Pemecah Masalah dengan C
//Modul		: 2
//Percobaan	: 2
//Tanggal	: 22 Februari 2018
//Nama(NIM)	: Indah Dwi Rizki Amas (13116010)
//Nama file	: Problem3
//Deskripsi	: sebuah program untuk menghitung volum tabung

#include <stdio.h>
#include <math.h>

int main (void){
	//Deklarasi Variabel
	int r, t;
	float alas, volum, phi;
	phi = 3.14;
	
	//Algoritma
	printf	("Masukkan besar jari-jari tabung	: ");
	scanf	("%d", &r);
	printf	("Masukkan besar tinggi tabung	: ");
	scanf	("%d", &t);
	
	//Perhitungan
	alas = phi*pow(r,2);
	volum = alas*t;
	
	//Output
	printf	("\nBesar Volume Tabung		: %.2f\n", volum);
	return 0;
	
}
