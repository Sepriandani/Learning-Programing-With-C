//Praktikum EL2208 Pemecah Masalah dengan C
//Modul		: 2
//Percobaan	: 2
//Tanggal	: 22 Februari 2018
//Nama(NIM)	: Indah Dwi Rizki Amas (13116010)
//Nama file	: Problem4
//Deskripsi	: sebuah program untuk mendefinisikan suatu bilangan satuan, puluhan, ratusan, ribuan.

#include <stdio.h>
#include <math.h>

int main (void)
{
	//Deklarasi variabel
	int a;
	
	//Algoritma
	printf	("Masukkan Bilangan	: ");
	scanf	("%d", &a);
	
	if	(a>=0 && 9>=a){
		printf	("%d Adalah Bilangan Satuan\n", a);
	}else if	(a>=10 && 99>=a){
		printf	("%d Adalah Bilangan Puluhan\n", a);
	}else if	(a>=100 && 999>=a){
		printf	("%d Adalah Bilangan Ratusan\n", a);
	}else if	(a>=1000 && 9999>=a){
		printf	("%d Adalah Bilangan Ribuan\n", a);
	}else		{
		printf	(" %d BUKAN BILANGAN SATUAN, PULUHAN, RATUSAN atau RIBUAN!!!", a);
	}
	return 0;
}
