//Praktikum EL2208 Pemecah Masalah dengan C
//Modul		: 2
//Percobaan	: 2
//Tanggal	: 22 Februari 2018
//Nama(NIM)	: Indah Dwi Rizki Amas (13116010)
//Nama file	: Problem5
//Deskripsi	: sebuah program untuk mencari nilai cosinus

#include <stdio.h>
#include <math.h>

int main (void)
{
	//Deklarasi Variabel
	int c;
	float result, phi;
	phi = 3.14;
	
	//Alogaritma
	printf	("Masukkan Besar Sudut	: ");
	scanf	("%d", &c);
	
	result = (cos (c*phi/180));
	printf	("cos(%d) Adalah %.2f", c, result);
	return 0;
}
