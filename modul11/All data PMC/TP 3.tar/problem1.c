//Praktikum EL2208 Pemecah Masalah dengan C
//Modul		: 3
//Percobaan	: 3
//Tanggal	: 27 Februari 2018
//Nama(NIM)	: Indah Dwi Rizki Amas (13116010)
//Nama file	: Problem1
//Deskripsi	: Tagihan Listrik

#include <stdio.h>
#include <math.h>

int main(void)
{
	float penggunaan, biayadasar, penggu, waktuguna, waktugunaset, a, subtotal, pajak, total;
	char pilih, jenis;
	
	printf ("Masukkan Jumlah Penggunaan (kWh): ");
	scanf ("%f", & penggunaan);

	printf ("Masukkan Jenis Pelanggan 	:");
	scanf ("%s", &jenis);

switch (jenis)
	{
		case 'R':
		case 'r':
		subtotal =(penggunaan*0.125)+7.00;
		total=(pajak+subtotal);
		pajak =(0.0523*subtotal);
		break;

	case 'C':
	case 'c':
	if (penggunaan <= 1000) {
		biayadasar = 40;
		penggu= 0.125;
		subtotal = (penggunaan*penggu)+biayadasar;
		pajak = 0.0523 * subtotal;
		total= pajak + subtotal;
	}
	else if (penggunaan >= 1000){
		biayadasar = 40;
		penggu= 0.10;
		waktuguna = 1000;
		subtotal = (penggunaan*penggu)+biayadasar;
		pajak = 0.0523 * subtotal;
		total= pajak + subtotal;}
		break;

	case 'I':
	case 'i':
	
	printf ("Masukkan 'P' untuk beban puncak dan 'S' untuk off-peak atau beban standar : ");
	scanf ("%s", &pilih);

	biayadasar = 100;
	penggu= 0.10;
	waktugunaset = 0.075;

	if (pilih == 'P'||'p') {if (penggunaan <= 1000) {subtotal = (penggunaan*0.15)+100;
		pajak = 0.0523*subtotal;
		total = pajak+subtotal;}
	
	if (penggunaan > 1000) {subtotal = (penggunaan*0.125)+100;
		pajak = 0.0523*subtotal;
		total = subtotal+pajak;}
	}

	if (pilih == 'S'||'s') {if (penggunaan <= 1000) {subtotal = (penggunaan*0.1)+50;
		pajak = 0.0523*subtotal;
		total = subtotal+pajak;}
		if (penggunaan > 1000) {subtotal = (penggunaan*0.075)+50;
		pajak = 0.0523*subtotal;
		total = subtotal+pajak;}}
		break;
		}
	printf ("\n\nData Penggunaan Listrik:\n\n");
	printf ("\n");
	printf ("Kilowatt_Hours		:$ %.2lf\n", (penggunaan));
	printf ("Subtotal		:$ %.2lf\n", (subtotal));
	printf ("Pajak			:$ %.2lf\n", pajak);
	printf ("Total yang dibayar	:$ %.2lf\n", total);

	return 0;
}
