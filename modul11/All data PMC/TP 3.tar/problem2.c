//Praktikum EL2208 Pemecah Masalah dengan C
//Modul		: 3
//Percobaan	: 3
//Tanggal	: 27 Februari 2018
//Nama(NIM)	: Indah Dwi Rizki Amas (13116010)
//Nama file	: Problem2
//Deskripsi	: Matriks

#include <stdio.h>

int main (void){
	int A [3][3], baris, kolom;
	for	(kolom = 0; kolom<3; kolom++){
	for (baris = 0; baris<3; baris++){
	printf	("Masukkan Nilai Matriks A [%d][%d]	: ", baris+1, kolom+1);
	scanf	("%d", &A[baris][kolom]);}
	}
	for	(baris = 0; baris<3; baris++){
	
	for	(kolom=0; kolom<3; kolom++){
	
	printf	("%3d", A[kolom][baris]);}
	printf	("\n");}
	return 0;
}

