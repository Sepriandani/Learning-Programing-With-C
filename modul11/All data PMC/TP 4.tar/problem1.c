//Pratikum EL2208 Pemecahan Masalah dengan C
//Modul			: 4
//Percobaan		: 1
//Tanggal		: 28 Februari 2018
//Nama(NIM) 	: Indah Dwi Rizki Amas (13116010)
//Nama file		: Problem1
//Deskripsi		: Bilangan Armstrong0


#include <stdio.h>

int main (void){

	//Deklarasi Variabel
 	int a, b, c, e = 0;

	//Algoritma
    printf	("Masukkan Angka yang akan Dianalisis	: ");
    scanf	("%d", &a);

    b = a;

    while (b!=0){
 	c = b%10;
    e += pow(c,3);
    b /= 10;
    }
    if(e==a)
        printf	("\n%d adalah Bilangan Amstrong",a);
    else
        printf	("\n%d adalah BUKAN BILANGAN AMSTRONG!!",a);
    return 0;
}
