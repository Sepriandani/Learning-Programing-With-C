//Pratikum EL2208 Pemecahan Masalah dengan C
//Modul			: 4
//Percobaan		: 2
//Tanggal		: 28 Februari 2018
//Nama(NIM) 	: Indah Dwi Rizki Amas (13116010)
//Nama file		: Problem1
//Deskripsi		: Perkalian Matriks

#include <stdio.h>

//SubProgram
void kali(int, int, int [][10], int, int, int [][10], int [][10]);
void result(int, int, int[][10]);

int main(){
	//Deklarasi Variabel
    int A[10][10];
	int B[10][10];
	int C[10][10] = {0};
    int a, b, c, d, i, j, k;

	//Algoritma
    printf	("Masukkan Jumlah Baris dan Kolom Matriks A: ");
	scanf	("%d%d", &a, &b);
    printf	("Masukkan Jumlah Baris dan Kolom Matriks B: ");
	scanf	("%d%d", &c, &d);
    if (b != c){
        printf	("Matriks tidak mungkin dioperasikan.");
    }else{
        printf	("Input matriks A: ");
        for (i = 0; i < a; i++)
        for (j = 0; j < b; j++){
        scanf("%d", &A[i][j]);
    }
        printf	("\nInput matriks B: ");
        for (i = 0; i < c; i++)
        for (j = 0; j < d; j++)
        {
            scanf("%d", &B[i][j]);
        }
        kali(a, b, A, c, d, B, C);
    }
    printf("Hasil perkalian matriks A dan B: ");
    result(a, d, C);
}
void kali (int a, int b, int A[10][10], int c, int d, int B[10][10], int C[10][10])
{
    static int i = 0, j = 0, k = 0;
    if (i >= a){
        return;
    }else if (i < a){
        if (j < d){
        if (k < b){
        	C[i][j] += A[i][k] * B[k][j];
            k++;
            kali(a, b, A, c, d, B, C);}
            k = 0;
            j++;
            kali(a, b, A, c, d, B, C);
			}
        j = 0;
        i++;
        kali(a, b, A, c, d, B, C);
    }
}
void result(int a, int d, int C[10][10]){
    int i, j;
    for (i = 0; i < a; i++){
        for (j = 0; j < d; j++){
        printf("%d  ", C[i][j]);}
        printf("\n");
    }
}

