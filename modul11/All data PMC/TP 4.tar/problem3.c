//Pratikum EL2208 Pemecahan Masalah dengan C
//Modul			: 4
//Percobaan		: 3
//Tanggal		: 28 Februari 2018
//Nama(NIM) 	: Indah Dwi Rizki Amas (13116010)
//Nama file		: Problem3
//Deskripsi		: Nilai dan Alamat

#include <stdio.h>
int main(void){
	//Deklarasi Variabel
    int a, *p, **q;
	
	//Algoritma
    printf	("Masukan input integer : ");
    scanf	("%d",&a);
    p=&a;
    q=&p;

    printf	("Nilai dari a    : %d\n",a);
    printf	("Alamat dari a   : %p\n",&a);
    printf	("Nilai dari *p   : %d\n",*p);
    printf	("Alamat dari p   : %p\n",&p);
    printf	("Alamat dari **p : %p\n",*q);
    printf	("Alamat dari *q  : %p\n",q);
    printf	("Nilai dari q    : %d\n",*q);
    return 0;
}
