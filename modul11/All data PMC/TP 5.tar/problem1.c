// Praktikum El2206 Pemecahan Masalah Dengan C
// Modul 		: 5
// Percobaan 	: 1
// Tanggal 		: 1 Maret 2018
// Nama (NIM) 	: Indah Dwi Rizki Amas (13116010)
// Nama File 	: problem1
// Deskripsi 	: Akuisisi Elemen Tabel Statik dan Menampilkan Isi Tabel Statik

#include <stdio.h>

void tabel(){
	printf("\n--------------------\n");
    printf("	TABEL		\n");
    printf("--------------------\n");
    printf("Indeks	Isi  Tabel\n");
}
int main (){
	int inputan;
	int i,a,b;
	int indeks[100];
	
a:
b:
    printf ("### AKUISISI TABEL STATIK ###\n");
    printf ("Jumlah elemen yang akan dimasukkan ke tabel : ");
    scanf("%d", &inputan);
	if(inputan >= 0 && inputan <=100){
        if (inputan==0){
        	printf("\n### MENAMPILKAN ISI TABEL STATIK ###\n");
        	printf("Tabel kosong");
        }else if (inputan>=0 && inputan<=100){
        printf("\n### MENAMPILKAN ISI TABEL STATIK ###\n");

            for(i=0; i<inputan; i++){
            	printf("Masukkan Elemen ke-%d : ", i);
            	scanf("%d", &indeks[i]);
            }
    		tabel();        
                for (i=0; i<inputan; i++){
                	printf(" %d\t\t%d \n", i, indeks[i]);
                }
                printf("--------------------\n");
         }
      }else if(inputan < 0){
        printf ("Masukan salah! Jumlah yang dapat ditampung tabel = [0 - 100]. Mohon Ulangi.\n\n");
		goto a;
      }else if(inputan > 100){
        printf ("Masukan salah! Jumlah yang dapat ditampung tabel = [0 - 100]. Mohon Ulangi.\n\n");
		goto b;
	  }
return 0;
}
