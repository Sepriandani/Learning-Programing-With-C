// Praktikum El2206 Pemecahan Masalah Dengan C
// Modul 		: 5
// Percobaan 	: 2
// Tanggal 		: 1 Maret 2018
// Nama (NIM) 	: Indah Dwi Rizki Amas (13116010)
// Nama File 	: problem2
// Deskripsi 	: Akuisisi Elemen Tabel Dinamik dan Menampilkan Isi Tabel Dinamik

#include <stdio.h>

void tabel(){
	printf("\n--------------------\n");
    printf("	TABEL		\n");
    printf("--------------------\n");
    printf("Indeks	Isi  Tabel\n");
}
int main (){
	int inputan;
	int i,a;
	int indeks[100];
	
a:
    printf ("### AKUISISI TABEL STATIK ###\n");
    printf ("Jumlah elemen yang akan dimasukkan ke tabel : ");
    scanf("%d", &inputan);
	if(inputan >= 0){
        if (inputan==0){
        	printf("\n### MENAMPILKAN ISI TABEL STATIK ###\n");
        	printf("Tabel kosong");
        }else if (inputan>=0){
        printf("\n### MENAMPILKAN ISI TABEL STATIK ###\n");

            for(i=0; i<inputan; i++){
            	printf("Masukkan Elemen ke-%d : ", i);
            	scanf("%d", &indeks[i]);
            }
    		tabel();        
                for (i=0; i<inputan; i++){
                	printf(" %d\t\t%d \n", i, indeks[i]);
                }
                printf("--------------------\n");
         }
      }else{
        printf ("Masukan salah! Jumlah elemen harus >= 0\n\n");
		goto a;
      }
return 0;
}
